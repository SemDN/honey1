let productCard = [
    {id: '001',img:"img/product/1.jpg", title:"Майский", deck:"", price: "1800₸"},
    {id: '002',img:"img/product/2.jpg", title:"Липовый", deck:"", price: "2500₸"},
    {id: '003',img:"img/product/3.jpg", title:"Цветочный", deck:"", price: "2 800₸"},
    {id: '004',img:"img/product/4.jpg", title:"Нектар облепиховый с мёдом", deck:"", price: "1900₸"},
    {id: '005',img:"img/product/5.png", title:"Донник ", deck:"", price: "2000₸"},
    {id: '006',img:"img/product/6.webp", title:"Кипрейный", deck:"", price: "2600₸"},
    {id: '007',img:"img/product/7.webp", title:"Гречишный", deck:"", price: "2500₸"},
    {id: '008',img:"img/product/8.webp", title:"Горное разнотравье", deck:"", price: "2500₸"},
   

]

let cartModal=[
    {id: '001',img:"img/modal_cart/1.png", title:"Сырный бортик", price: "800"},
    {id: '001',img:"img/modal_cart/2.png", title:"Моцарелла", price: "350тг"},
    {id: '001',img:"img/modal_cart/3.png", title:"Чеддер и пармезан", price: "350тг"},
    {id: '001',img:"img/modal_cart/4.png", title:"Острый халапеньо", price: "350тг"},
    {id: '001',img:"img/modal_cart/5.png", title:"Цыпленок", price: "250тг"},
    {id: '001',img:"img/modal_cart/6.png", title:"Шампиньоны", price: "350тг"},
    {id: '001',img:"img/modal_cart/7.png", title:"Ветчина из цыпленка", price: "350тг"},
    {id: '001',img:"img/modal_cart/8.png", title:"Острые колбаски чоризо", price: "350тг"},
    {id: '001',img:"img/modal_cart/9.png", title:"Маринованные огурчики", price: "350тг"},
    {id: '001',img:"img/modal_cart/10.png", title:"Томаты", price: "250тг"},
    {id: '001',img:"img/modal_cart/11.png", title:"Красный лук", price: "250тг"},
    {id: '001',img:"img/modal_cart/12.png", title:"Ананасы", price: "250тг"},
]